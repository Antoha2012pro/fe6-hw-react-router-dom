const { createBrowserRouter } = "react-router";
import App from "../App";
import Home from "../components/pages/Home";
import Movies from "../components/pages/Movies";
import MovieDetails from "../components/pages/movies/MovieDetails";

const router = createBrowserRouter([
    {
        path: "/",
        Component: App,
        children: [
            {
                index: true,
                Component: Home,
            },
            // {
            //     path: "movies",
            //     Component: Movies,
            //     children: [
            //         {
            //             path: "/:movieId",
            //             Component: MovieDetails,
            //         }
            //     ]
            // }
        ]
    }
]);

export default router;