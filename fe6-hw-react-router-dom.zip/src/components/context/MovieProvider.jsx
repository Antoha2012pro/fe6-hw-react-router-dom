import React from 'react'
import { MovieContext } from '../../shared/context/movieContext'

const MovieProvider = ({children}) => {
    const value = {
        
    }

  return (
    <MovieContext value={value}>{children}</MovieContext>
  )
}

export default MovieProvider
