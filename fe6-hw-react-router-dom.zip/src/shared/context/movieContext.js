import { createContext, useContext } from "react";

export const MovieContext = createContext();

export const useMovie = () => {
  const context = useContext(MovieContext);
  if (!context) throw new Error("useMovie ties must be used inside MovieProvider");
  return context;
};
